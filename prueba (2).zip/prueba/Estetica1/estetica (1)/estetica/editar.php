<?php 
include("conexion.php");
include("index.php");

$codigo = $_GET['id_cliente'];
 
$queryclientes = mysqli_query($conexion, "SELECT * FROM clientes WHERE $codigo=id_cliente");
 
while($mostrar = mysqli_fetch_array($queryclientes))
{
    $id_cliente = $mostrar['id_cliente'];
    $nombre = $mostrar['nombre'];
    $apellido = $mostrar['apellido'];
    $email = $mostrar['email'];
	$telefono = $mostrar['telefono'];
}
?>
<html>
<head>    
		<title>t4</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="Style.css">
</head>
<body>
<div class="caja_popup2" id="formmodificar">
  <form method="POST" class="contenedor_popup" >
      
        <table>
		<tr><th colspan="2">Modificar usuario</th></tr>
		 
            <tr> 
                <td>Nombre</td>
                <td><input type="text" name="nombre" value="<?php echo $nombre;?>" required></td>
            </tr>
            <tr> 
                <td>Apellido</td>
                <td><input type="text" name="apellido" value="<?php echo $apellido;?>" required></td>
            </tr>
            <tr> 
                <td>Correo</td>
                <td><input type="email" name="email" value="<?php echo $email;?>" required></td>
            </tr>
            <tr> 
                <td>Teléfono</td>
                <td><input type="text" name="telefono" value="<?php echo $telefono;?>"required></td>
            </tr>
            <tr>
				
                <td colspan="2">
				<a href="index.php">Cancelar</a>
				<input type="submit" name="btnmodificar" value="Modificar" onClick="javascript: return confirm('¿Deseas modificar a este usuario?');">
				</td>
            </tr>
        </table>
    </form>
</div>
</body>
</html>

<?php
	
	if(isset($_POST['btnmodificar']))
{    
    $id_cliente= $_REQUEST['id_cliente'];
    $nombre= $_POST['nombre'];
    $apellido= $_POST['apellido'];
    $email= $_POST['email'];
    $telefono= $_POST['telefono'];
 
    $query="UPDATE clientes SET nombre='$nombre', apellido='$apellido', email='$email', telefono='$telefono' WHERE id_cliente='$id_cliente'";
    $resultado= $conexion->query($query);
 
  	echo "<script>window.location= 'index.php' </script>";
    


      
}
?>

	