<?php
//Hace conexión con conexión.php
include("conexion.php");
//Declara las variables nombre, apellido, correo
  $nombre= $_POST['nombre'];
  $apellido= $_POST['apellido'];
  $email= $_POST['email'];
  $telefono= $_POST['telefono'];
//Inserta en la tabla "usuarios" el nombre, el apellido y el correo las variables declaradas anteriormente
  $query="INSERT INTO clientes(nombre,apellido,email,telefono) VALUES('$nombre','$apellido','$email','$telefono')";
//Abre conexión
  $resultado= $conexion->query($query);
//Si hay conexión los datos se llevarán hacía la tabla
  if($resultado){
    header("Location: index.php");
  }
  //Si no hay conexión aparecerá lo siguiente
  else{
    echo "Insercion no exitosa";
  }

?>
