<?php
require_once('config.php');
$id_cliente   		= $_REQUEST['id_cliente']; 

$sqlDeleteEvento = ("DELETE FROM eventoscalendar WHERE  =id_cliente'" .$id_cliente. "'");
$resultProd = mysqli_query($con, $sqlDeleteEvento);

?>
  