<?php
//Conexión básica a la base de datos, utiliza, usuario, contraseña (por defecto no tiene) y el nombre de la base de datos
//Hay que asegurarse que la base de datos esté bien escrita, de lo contrario dará error
$conexion = new mysqli("localhost","root","","eventos");
?>﻿
